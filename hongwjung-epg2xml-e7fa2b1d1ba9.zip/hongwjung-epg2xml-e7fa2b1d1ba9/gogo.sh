#!/bin/sh
git pull --rebase
cat xmltv.xml | socat - UNIX-CONNECT:/sock/xmltv.sock

