# 공지
1. git clone https://flywithu@bitbucket.org/flywithu/epg2xml.git
2. ./gogo.sh   

=> cat xmltv.xml | socat - UNIX-CONNECT:/sock/xmltv.sock 에서 UNIX-CONNECT Socket은 재지정